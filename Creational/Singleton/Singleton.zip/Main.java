class Main {
  public static void main(String[] args) {
   Singleton message = Singleton.getIntance();

   message.setMessage("Olá Mundo");

   System.out.println(message.getMessage());
  }
}