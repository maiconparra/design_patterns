import java.io.File;

public final class Singleton
{
  private String message;

  private Singleton()
  {
    
  }

  public void setMessage(String message)
  {
    this.message = message;
  }

  public String getMessage()
  {
    return this.message;
  }

  public static Singleton getIntance()
  {
    Singleton instance = new Singleton();
  
    return instance;
  }
}